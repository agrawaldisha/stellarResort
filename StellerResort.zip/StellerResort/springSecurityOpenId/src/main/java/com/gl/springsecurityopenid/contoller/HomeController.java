package com.gl.springsecurityopenid.contoller;

public class HomeController {
}
