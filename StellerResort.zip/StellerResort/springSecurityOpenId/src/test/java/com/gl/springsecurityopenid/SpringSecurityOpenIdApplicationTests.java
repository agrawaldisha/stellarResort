package com.gl.springsecurityopenid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityOpenIdApplicationTests {

	@Test
	void contextLoads() {
	}

}
