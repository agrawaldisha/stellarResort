package com.gl.room.service;

import com.gl.room.entity.Room;
import com.gl.room.repository.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RoomService {

    @Autowired
    private RoomRepository roomRepository;

    public Room createRoom(Room room) {
        return roomRepository.save(room);
    }

    public List<Room> getAllRooms() {
        return roomRepository.findAll();
    }

    public Optional<Room> getRoomById(int id) {
        return roomRepository.findById(id);
    }

    public Room updateRoom(int id, String rtype) {
        return roomRepository.findById(id)
                .map(room -> {
                    room.setRtype(rtype);
                    return roomRepository.save(room);
                })
                .orElseThrow(() -> new RuntimeException("Room not found with id " + id));
    }

    public void deleteRoom(int id) {
        roomRepository.deleteById(id);
    }
    public List<Room> getRoomsByIds(List<Integer> rids) {
        return roomRepository.findByRidIn(rids);
    }
}
