package com.gl.room.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Room")
public class Room {
    @Id
    private int rid;
    private String rtype;

    // No-argument constructor
    public Room() {
    }

    // Full-argument constructor
    public Room(int rid, String rtype) {
        this.rid = rid;
        this.rtype = rtype;
    }

    // Getters and Setters
    public int getRid() {
        return rid;
    }

    public void setRid(int rid) {
        this.rid = rid;
    }

    public String getRtype() {
        return rtype;
    }

    public void setRtype(String rtype) {
        this.rtype = rtype;
    }

    // toString method
    @Override
    public String toString() {
        return "Room{" +
                "rid=" + rid +
                ", rtype='" + rtype + '\'' +
                '}';
    }
}
