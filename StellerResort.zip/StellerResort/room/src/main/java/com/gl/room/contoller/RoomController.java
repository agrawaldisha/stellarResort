package com.gl.room.contoller;


import com.gl.room.entity.Room;
import com.gl.room.service.RoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
@RestController

public class RoomController {

    @Autowired
    private RoomService roomService;

    @PostMapping("/room")
    public ResponseEntity<Room> createRoom(@RequestBody Room room) {
        Room createdRoom = roomService.createRoom(room);
        return ResponseEntity.ok(createdRoom);
    }

    @GetMapping("/room")
    public ResponseEntity<List<Room>> getAllRooms() {
        List<Room> rooms = roomService.getAllRooms();
        return ResponseEntity.ok(rooms);
    }

    @GetMapping("/room/{id}")
    public ResponseEntity<Optional<Room>> getRoomById(@PathVariable int id) {
        Optional<Room> room = roomService.getRoomById(id);
        return room.isPresent() ? ResponseEntity.ok(room) : ResponseEntity.notFound().build();
    }

    @PutMapping("/rooms/{id}")
    public ResponseEntity<Room> updateRoom(@PathVariable int id, @RequestParam String rtype) {
        Room updatedRoom = roomService.updateRoom(id, rtype);
        return ResponseEntity.ok(updatedRoom);
    }

    @DeleteMapping("/room/{id}")
    public ResponseEntity<String> deleteRoom(@PathVariable int id) {
        roomService.deleteRoom(id);
        return ResponseEntity.ok("Room with ID " + id + " has been deleted successfully");
    }
}

