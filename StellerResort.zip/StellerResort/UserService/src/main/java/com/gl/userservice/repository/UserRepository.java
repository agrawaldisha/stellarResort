package com.gl.userservice.repository;

import com.gl.userservice.entity.User1;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.web.bind.annotation.RestController;

@RestController
public interface UserRepository extends JpaRepository<User1, Long> {
//    Optional<User> findByName(String name);
//    Optional<User> findByEmail(String email);
}
