package com.gl.userservice.controller;

import com.gl.userservice.entity.User1;
import com.gl.userservice.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
//@RequestMapping("/users")
public class UserController {

    @Autowired
    UserService userService;
    @PostMapping("/register")
    public User1 register(@RequestBody User1 user) {
        User1 createdUser = userService.register(user);
        return ResponseEntity.ok(createdUser).getBody();
    }
    @GetMapping("/Users")
    public List<User1> getAllUsers() {
        return userService.getAllUsers();
    }
    @GetMapping("users/{id}")
        public Optional<User1> getUserById(@PathVariable long id) {
        return userService.getUserById(id);
    }
    @PutMapping("/updateUser")
    public User1 updateCustomer(@RequestParam long id, String password) {
        return userService.updateUser(id,password);
    }
    @DeleteMapping("/deleteUser/{id}")
    public String deleteUser(@PathVariable long id) {
        userService.deleteUser(id);
        return "User with ID " + id + " has been deleted successfully";
    }


}

