package com.gl.userservice.service;

import com.gl.userservice.entity.User1;
import com.gl.userservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    @Autowired
    UserRepository userRepository;
    public User1 register(User1 user) {
        return userRepository.save(user);
    }

    public List<User1> getAllUsers() {
        return userRepository.findAll();
    }

    public Optional<User1> getUserById(Long id) {
        return userRepository.findById(id);
    }
    public User1 updateUser(long id, String password) {
        return userRepository.findById(id)
                .map(user -> {
                    user.setPassword(password);
                    return userRepository.save(user);
                })
                .orElseThrow(() -> new RuntimeException("Customer not found with id " + id));
    }

    public void deleteUser(long id) {
        userRepository.deleteById(id);
    }

}
