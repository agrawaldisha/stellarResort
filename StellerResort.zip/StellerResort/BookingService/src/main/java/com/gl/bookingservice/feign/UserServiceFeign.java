package com.gl.bookingservice.feign;

import com.gl.bookingservice.dto.Room;
import com.gl.bookingservice.dto.User1;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient("userservice")
public interface UserServiceFeign {
    @GetMapping("/users/{id}")
    User1 getUserById(@PathVariable long id) ;
    @PostMapping("/register")
    User1 register(@RequestBody User1 user) ;
}
