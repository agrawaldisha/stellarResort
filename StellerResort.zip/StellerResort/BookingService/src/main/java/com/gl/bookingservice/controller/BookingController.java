package com.gl.bookingservice.controller;

import com.gl.bookingservice.dto.BookingDTO;
import com.gl.bookingservice.dto.Room;
import com.gl.bookingservice.dto.User1;
import com.gl.bookingservice.entity.BookingDetails;
import com.gl.bookingservice.feign.RoomServiceFeign;
import com.gl.bookingservice.feign.UserServiceFeign;
import com.gl.bookingservice.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController

public class BookingController {

    @Autowired
    private BookingService bookingService;
   @Autowired
    UserServiceFeign userServiceFeign;
    @Autowired
    private RoomServiceFeign roomServiceFeign;

    @PostMapping("/bookings")
    public ResponseEntity<BookingDetails> createBooking(@RequestBody BookingDetails bookingDetails) {
        BookingDetails createdBooking = bookingService.createBooking(bookingDetails);
        return ResponseEntity.ok(createdBooking);
    }

    @GetMapping("/bookings")
    public ResponseEntity<List<BookingDetails>> getAllBookings() {
        List<BookingDetails> bookings = bookingService.getAllBookings();
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/bookings/{id}")
    public ResponseEntity<Optional<BookingDetails>> getBookingById(@PathVariable int id) {
        Optional<BookingDetails> booking = bookingService.getBookingById(id);
        return booking.isPresent() ? ResponseEntity.ok(booking) : ResponseEntity.notFound().build();
    }

    @PutMapping("/bookings/{id}")
    public ResponseEntity<BookingDetails> updateBooking(@PathVariable int id, @RequestBody BookingDetails bookingDetails) {
        BookingDetails updatedBooking = bookingService.updateBooking(id, bookingDetails);
        return ResponseEntity.ok(updatedBooking);
    }

    @DeleteMapping("/bookings/{id}")
    public ResponseEntity<String> deleteBooking(@PathVariable int id) {
        bookingService.deleteBooking(id);
        return ResponseEntity.ok("Booking with ID " + id + " has been deleted successfully");
    }

//    @GetMapping("/getroom/{id}")
//    public BookingDTO getBookingByRoom(@PathVariable int id) {
//        BookingDetails bookingDetails = bookingService.getBookingById(id).orElse(null);
//        if (bookingDetails != null)
//            return null;
//        int userId = (int) bookingDetails.getUid();
//        System.out.println(userId);
//        List<Room> rooms = roomServiceClient.getall();
//        List<Room> filteredRooms = rooms.stream()
//                .filter(room -> room.getUid() == userId)
//                .collect(Collectors.toList());
//        BookingDTO bookingDTO = new BookingDTO();
//        bookingDTO.setRid(bookingDetails.getRid());
//        bookingDTO.setBid(bookingDetails.getBid());
//        bookingDTO.setUid(bookingDetails.getUid());
//        bookingDTO.setUser1(bookingDTO.getUser1());
//        bookingDTO.setRoom((Room) rooms);
//        return bookingDTO;

//    @GetMapping("/getRoomsByBookingId/{id}")
//    public List<Room> getRoomsByBookingId(@PathVariable int bookingId) {
//        return bookingService.findRoomsByBookingId(bookingId);
//    }

    @GetMapping("/BookingUser/{id}")
    public BookingDTO getBookingUser(@PathVariable int id) {
        BookingDTO bookingDTO=new BookingDTO();
        BookingDetails bookingDetails=bookingService.getBookingById(id).get();
        long uId=bookingDetails.getUid();
        User1 user=userServiceFeign.getUserById(uId);
        List<Integer> roomIdslist= bookingService.getRoomIdsByUserId(uId);
        List<Room> rooms = getRoomsDetailsByIds(roomIdslist);
        bookingDTO.setBid(bookingDetails.getBid());
        bookingDTO.setRid(bookingDetails.getRid());
        bookingDTO.setUid(bookingDetails.getUid());
        bookingDTO.setUser1(user);
        bookingDTO.setRoom(rooms);
        return bookingDTO;
    }
//    public List<Integer> getRoomIdsByUserId(Long userId) {
//        List<Integer> list= bookingService.getRoomIdsByUserId(userId);
//        System.out.println(list);
//        return list;
//    }
//    public List<Room> getAllRooms() {
//        List<Room> list=roomServiceFeign.getRooms();
//        System.out.println(list);
//        return list;
//    }
    public List<Room> getRoomsDetailsByIds(List<Integer> roomIds) {
        List<Room> rooms = new ArrayList<>();
        for (int roomId : roomIds) {
            Room room = roomServiceFeign.getRoomById(roomId);
            if (room != null) {
                rooms.add(room);
            } else {
                // Handle the case where a room is not found, if necessary
            }
        }
        return rooms;
}
//    @GetMapping("/roomlist/{id}")
//    public ResponseEntity<List<Room>> getRoomList(@PathVariable long id) {
//        List<Integer> roomIds = bookingService.getRoomIdsByUserId(id);
//        try {
//            System.out.println(roomIds);
//        } catch (Exception e) {
//            throw new RuntimeException(e);
//        } finally {
//        }
//        return ResponseEntity.ok(rooms);
//    }


// Assuming necessary imports and class annotations

    @PostMapping("/BookingUser")
    public ResponseEntity<BookingDTO> createBookingUser(@RequestBody BookingDTO bookingDTO) {
        // Extract user details
        User1 user = bookingDTO.getUser1();

        // Save or update the user
        User1 savedUser = userServiceFeign.register(user);

        // Extract room details
        List<Room> rooms = bookingDTO.getRoom();
        List<Integer> roomIds = new ArrayList<>();

        for (Room room : rooms) {
            // Save or update each room
            Room savedRoom = roomServiceFeign.createRoom(room).getBody();
            roomIds.add(savedRoom.getRid());
        }

        // Create booking entry
        BookingDetails bookingDetails = new BookingDetails();
        bookingDetails.setBid(bookingDTO.getBid());
        bookingDetails.setUid(savedUser.getId());
        bookingDetails.setRid(bookingDTO.getRid()); // This assumes that rid is a specific room ID related to the booking

        // Save the booking details
        BookingDetails savedBooking = bookingService.createBooking(bookingDetails);

        // Prepare response
//        bookingDTO.setBid(savedBooking.getBid());
        bookingDTO.setUid(savedBooking.getUid());
        bookingDTO.setRid(savedBooking.getRid());
        bookingDTO.setUser1(savedUser);
        bookingDTO.setRoom(rooms);

        return ResponseEntity.ok(bookingDTO);
    }

}


