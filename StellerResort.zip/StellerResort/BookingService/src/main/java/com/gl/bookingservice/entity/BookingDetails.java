package com.gl.bookingservice.entity;

import jakarta.persistence.*;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RestController;

@Entity
@Table(name="BookingDetails")
public class BookingDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-generates the bid
    private int bid;

    private long uid; // Assuming this links to a user
    private int rid;  // Assuming this links to a room

    // No-argument constructor
    public BookingDetails() {
    }

    // Parameterized constructor
    public BookingDetails(long uid, int rid) {
        this.uid = uid;
        this.rid = rid;
    }

    // Getters and Setters
    public int getBid() {
        return bid;
    }

    public void setBid(int bid) {
        this.bid = bid;
    }

    public long getUid() {
        return uid;
    }

    public void setUid(long uid) {
        this.uid = uid;
    }

    public int getRid() {
        return rid;
    }

    public void setRid(int rid) {
        this.rid = rid;
    }

    // toString method
    @Override
    public String toString() {
        return "BookingDetails{" +
                "bid=" + bid +
                ", uid=" + uid +
                ", rid=" + rid +
                '}';
    }
}
