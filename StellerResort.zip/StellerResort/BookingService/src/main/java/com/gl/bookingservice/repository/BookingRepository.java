package com.gl.bookingservice.repository;

import com.gl.bookingservice.entity.BookingDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface BookingRepository extends JpaRepository<BookingDetails, Integer> {

    // Method to find all booking details by user ID
    List<BookingDetails> findByUid(long userId);

    // Method to find all room IDs by user ID
    @Query("SELECT b.rid FROM BookingDetails b WHERE b.uid = :uid")
    List<Integer> findRoomIdsByUserId(@Param("uid") Long uid);
}
