package com.gl.bookingservice.dto;
public class Room {

    private int rid;
    private String rtype;

    // No-argument constructor
    public Room() {
    }

    // Full-argument constructor
    public Room(int rid, String rtype) {
        this.rid = rid;
        this.rtype = rtype;
    }

    // Getters and Setters
    public int getRid() {
        return rid;
    }

    public void setRid(int rid) {
        this.rid = rid;
    }

    public String getRtype() {
        return rtype;
    }

    public void setRtype(String rtype) {
        this.rtype = rtype;
    }

    // toString method
    @Override
    public String toString() {
        return "Room{" +
                "rid=" + rid +
                ", rtype='" + rtype + '\'' +
                '}';
    }
}
