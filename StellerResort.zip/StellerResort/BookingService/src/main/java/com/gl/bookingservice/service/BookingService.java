package com.gl.bookingservice.service;

import com.gl.bookingservice.dto.Room;
import com.gl.bookingservice.entity.BookingDetails;
//import com.gl.bookingservice.feign.RoomServiceClient;
import com.gl.bookingservice.repository.BookingRepository;
import com.gl.bookingservice.service.BookingService;
import com.gl.bookingservice.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class  BookingService {

    @Autowired
    private BookingRepository bookingRepository;

//    @Autowired
//    private RoomServiceClient roomServiceClient;
    public BookingDetails createBooking(BookingDetails bookingDetails) {
        return bookingRepository.save(bookingDetails);
    }


    public List<BookingDetails> getAllBookings() {
        return bookingRepository.findAll();
    }

    public Optional<BookingDetails> getBookingById(int id) {
        return bookingRepository.findById(id);
    }

    public BookingDetails updateBooking(int id, BookingDetails bookingDetails) {
        return bookingRepository.findById(id)
                .map(existingBooking -> {
                    existingBooking.setUid(bookingDetails.getUid());
                    existingBooking.setRid(bookingDetails.getRid());
                    return bookingRepository.save(existingBooking);
                })
                .orElseThrow(() -> new RuntimeException("Booking not found with id " + id));
    }

    public void deleteBooking(int id) {
        bookingRepository.deleteById(id);
    }

    public List<Integer> getRoomIdsByUserId(Long userId) {
        return bookingRepository.findRoomIdsByUserId(userId);
    }

//    public List<Room> findRoomsByBookingId(int bookingId) {
//        Optional<BookingDetails> bookingOptional = bookingRepository.findById(bookingId);
//        if (bookingOptional.isEmpty()) {
//            return List.of(); // Return an empty list if the booking is not found
//        }
//
//        long userId = bookingOptional.get().getUid();
//        // Fetch all bookings for the userId
//        List<BookingDetails> userBookings = bookingRepository.findByUid(userId);
//
//        // Extract room IDs from the bookings
//        List<Long> roomIds = userBookings.stream()
//                .map(BookingDetails::getRid)
//                .map(Long::valueOf) // Convert Integer to Long
//                .collect(Collectors.toList());
//
//        // Fetch room details from the room service
//        List<Room> allRooms = roomServiceClient.getall();
//        return allRooms.stream()
//                .filter(room -> roomIds.contains(room.getRid()))
//                .collect(Collectors.toList());
    }
//}
