package com.gl.bookingservice.dto;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

import java.util.List;

public class BookingDTO {
    private int bid;
    private long uid; // Assuming this links to a user
    private int rid;  // Assuming this links to a room

    @Override
    public String toString() {
        return "BookingDTO{" +
                "bid=" + bid +
                ", uid=" + uid +
                ", rid=" + rid +
                ", room=" + room +
                ", user1=" + user1 +
                '}';
    }

    // No-argument constructor
    private List<Room> room;
    private User1 user1;

    public List<Room> getRoom() {
        return room;
    }

    public BookingDTO(int bid, long uid, int rid, Room room, User1 user1) {
        this.bid = bid;
        this.uid = uid;
        this.rid = rid;
        this.room = (List<Room>) room;
        this.user1 = user1;
    }

    public void setRoom(List<Room> room) {
        this.room = room;
    }

    public User1 getUser1() {
        return user1;
    }

    public void setUser1(User1 user1) {
        this.user1 = user1;
    }

    public BookingDTO() {
    }

    // Parameterized constructor
    public BookingDTO(long uid, int rid) {
        this.uid = uid;
        this.rid = rid;
    }

    // Getters and Setters
    public int getBid() {
        return bid;
    }

    public void setBid(int bid) {
        this.bid = bid;
    }

    public long getUid() {
        return uid;
    }

    public void setUid(long uid) {
        this.uid = uid;
    }

    public int getRid() {
        return rid;
    }

    public void setRid(int rid) {
        this.rid = rid;
    }

}
