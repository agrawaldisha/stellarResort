package com.gl.bookingservice.repository;

public @interface Query {
}
