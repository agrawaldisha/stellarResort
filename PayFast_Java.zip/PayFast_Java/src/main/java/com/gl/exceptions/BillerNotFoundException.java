package com.gl.exceptions;

public class BillerNotFoundException extends Exception{
    public BillerNotFoundException(String message) {
        super(message);
    }
}

