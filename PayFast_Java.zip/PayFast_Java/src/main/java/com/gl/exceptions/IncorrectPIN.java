package com.gl.exceptions;

public class IncorrectPIN extends Exception {
    public IncorrectPIN(String message) {
        super(message);
    }
}
