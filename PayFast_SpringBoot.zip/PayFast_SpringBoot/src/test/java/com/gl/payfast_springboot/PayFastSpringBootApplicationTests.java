package com.gl.payfast_springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PayFastSpringBootApplicationTests {

    @Test
    void contextLoads() {
    }

}
